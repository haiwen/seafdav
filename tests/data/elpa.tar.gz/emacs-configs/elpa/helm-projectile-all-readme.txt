Find files in all projects known to projectile.
