This library provides easy project management and navigation.  The
concept of a project is pretty basic - just a folder containing
special file.  Currently git, mercurial and bazaar repos are
considered projects by default.  If you want to mark a folder
manually as a project just create an empty .projectile file in
it.  See the README for more details.
